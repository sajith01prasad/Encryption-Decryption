
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author sajithprasad
 */
public class RandomKey {

    public static String generateString(Random random, String characters, int length) { //In this function a random string is going to be generated
        char[] text = new char[length];
        for (int i = 0; i < length; i++) {
            text[i] = characters.charAt(random.nextInt(characters.length())); // array "text" is filling with randomly generated characters. At the end we get an array filled with some characters that means a string
        }
        return new String(text); // Randomly generated String is returned
    }

}
