
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.Base64;
import javax.swing.JFileChooser;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author sajithprasad
 */
public class Encryption_decryption {

    private String decryptedValue;
    private String encryptedValue;
    
    // This is the method to ecnrypt individual text files
    public String encryption(SelectedFile selected_file, String randomString, JFileChooser fileChooser) {
        try {

            byte[] k = randomString.getBytes(); // create a byte array called k and store the byte value of randomString inside of it
            selected_file.setKey(k);// set the key value
            File file = new File(fileChooser.getSelectedFile().getAbsolutePath());// create a file object using the path of the text file which was selected
            selected_file.setFile(file); // set the file path
            FileInputStream fis = new FileInputStream(file); // create a FileInputStream object to read the content of the text file
            byte[] dataToSend = new byte[(int) file.length()]; // create a byte array called dataToSend and the size of it is same to the file size
            fis.read(dataToSend); // read the content of the text file and store those byte values in the dataToSend array
            fis.close(); // close the text file
            String str = new String(dataToSend, "UTF-8"); //convert dataToSend array to String and store the output in str variable
            

            //encryption
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding"); // Create an object out of Cipher class with the instances of AES and PKCS5Padding to fill up the rest of the fields
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");// create an object from SecretKeySpec class which supports AES encryption
            c.init(Cipher.ENCRYPT_MODE, sks);// set the mode to ENCRYPT_MODE
            byte[] encryptedData = c.doFinal(dataToSend); // encrypt using AES and store the output in the byte array called encryptedData 
            selected_file.setEncodedContent(encryptedData);// set the encrypted data

            encryptedValue = Base64.getEncoder().encodeToString(selected_file.getEncodedContent()); // convert encrypted output to string using a base64 encoder and store the new output in string variable
            selected_file.setEncodedContentString(encryptedValue);// set the encrypted string value
            
            PrintWriter out = new PrintWriter(selected_file.getFile()); // create an object from PrintWriter class to write the encrypted string to the text file
            out.println(encryptedValue); // print the encrypted string in the text file
            out.close(); // close the text file

        } catch (Exception e) {
        }
        return encryptedValue; // return encrypted string
    }
// This function is for the ecryption of text files inside a folder. Similar to the above code. difference is the method signature
    public String encryptionForTextFilesInFolder(selectedFolder selected_file, String randomString, JFileChooser fileChooser, String file_name) {
        try {
            // same set of codes in the previos function
            byte[] k = randomString.getBytes();
            selected_file.setKey(k);
            File file = new File(selected_file.getFolder_Path() + "\\" + file_name);
            selected_file.setFile(file);
            FileInputStream fis = new FileInputStream(file);
            byte[] dataToSend = new byte[(int) file.length()];
            fis.read(dataToSend);
            fis.close();
            String str = new String(dataToSend, "UTF-8");
            System.out.println(str);

            //encryption
           
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");
            c.init(Cipher.ENCRYPT_MODE, sks);
            byte[] encryptedData = c.doFinal(dataToSend);
            selected_file.setEncodedContent(encryptedData);

            encryptedValue = Base64.getEncoder().encodeToString(selected_file.getEncodedContent());
            selected_file.setEncodedContentString(encryptedValue);
        
            PrintWriter out = new PrintWriter(selected_file.getFile());
            out.println(encryptedValue);
            out.close();

        } catch (Exception e) {
        }
        return encryptedValue; // return encrypted string
    }
// This function is for the decryption of an individual text file
    public String decryption(SelectedFile selected_file, String randomString, JFileChooser fileChooser, String encoded) {
        try {
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");// create an object from Cipher class called c 
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES"); // create a secret key spec object called sks to do the AES deccryption
            c.init(Cipher.DECRYPT_MODE, sks); //Set the DECRYPT_MODE
            decryptedValue = new String(c.doFinal(Base64.getDecoder().decode(selected_file.getEncodedContentString())));// do the decryption and convert the output to String format using a base64 decoder and store the string output in a string variable
            PrintWriter out = new PrintWriter(selected_file.getFile());// create a PrintWriter object to the selected text file for writing purposes
            out.println(decryptedValue); // write the decrypted string to the text file
            out.close(); // close the text file
        } catch (Exception e) {
        }
        return decryptedValue; // return decrypted string
    }
// this function is for the decryption of text files in a folder
    public String decryptionForTextFilesInFolder(selectedFolder selected_file, String randomString, JFileChooser fileChooser, String file_name, String contentsInEachFile[], int i) {
        try {
            //same set of codes
            File file = new File(selected_file.getFolder_Path() + "//" + file_name);
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");
            c.init(Cipher.DECRYPT_MODE, sks);
            decryptedValue = new String(c.doFinal(Base64.getDecoder().decode(contentsInEachFile[i])));
            PrintWriter out = new PrintWriter(file);
            out.println(decryptedValue);
            out.close();
        } catch (Exception e) {
        }
        return decryptedValue; // return decrypted string

    }
// This function is for the encryption of an individual PDF file
    public String encryptionForPDF(SelectedFile selected_file, String randomString, JFileChooser fileChooser, String content) {
        try {
            byte[] k = randomString.getBytes();// create a byte array called k and store the byte value of randomString 
            byte[] con = content.getBytes();// create a byte array called con and store the byte value of conetent 
            selected_file.setKey(k);// set the keyValue
            Cipher c; // create an object from Cipher class called c
            c = Cipher.getInstance("AES/ECB/PKCS5Padding");// create an AES instance
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");// create a key for the encryption which supports AES
            c.init(Cipher.ENCRYPT_MODE, sks);//set mode to ENCRYPT_MODE
            byte[] encryptedData = c.doFinal(con); // create a byte array called encryptedData and store the encrypted value byte value inside of it
            selected_file.setEncodedContent(encryptedData); // set the encrypted byte value
            encryptedValue = Base64.getEncoder().encodeToString(selected_file.getEncodedContent());// get the string value of encryptedData using a base64 encoder 
            selected_file.setEncodedContentString(encryptedValue);// set the encoded string

        } catch (Exception e) {
        }
        return encryptedValue; // return encrypted string
    }
// This function is for the encryption of pdf files inside a folder
    public String encryptionForPDFFilesInFolder(selectedFolder selected_file, String randomString, JFileChooser fileChooser, String content, String file_name) {
        try {
            // same code
            byte[] k = randomString.getBytes();
            byte[] con = content.getBytes();
            selected_file.setKey(k);
            Cipher c;

            c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");
            c.init(Cipher.ENCRYPT_MODE, sks);
            byte[] encryptedData = c.doFinal(con);
            selected_file.setEncodedContent(encryptedData);

            encryptedValue = Base64.getEncoder().encodeToString(selected_file.getEncodedContent());
            selected_file.setEncodedContentString(encryptedValue);

        } catch (Exception e) {
        }
        return encryptedValue; // return encrypted string
    }
// This function is for the decryption of an individual pdf file
    public String decryptionForPDF(SelectedFile selected_file, String randomString, JFileChooser fileChooser, String content, String encoded) {
        try {
            byte[] con = content.getBytes();
            byte[] k = randomString.getBytes();
            selected_file.setKey(k);
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");
            c.init(Cipher.DECRYPT_MODE, sks); // set the mode to DECRYPT_MODE
            decryptedValue = new String(c.doFinal(Base64.getDecoder().decode(encoded))); // do the decryption and get the byte value of it and convert it into string using a base64 decoder and store the string output in a variable
           

        } catch (Exception e) {
        }
        return decryptedValue; // return decrypted string
    }
// This finction is for the decryption of pdf files inside a folder. code is same. method signature is different
    public String decryptionForPDFInFolder(selectedFolder selected_file, String randomString, JFileChooser fileChooser, String content, String encoded, String contentsInEachFile[], int i) {
        try {
            // same code above
            byte[] con = content.getBytes();
            byte[] k = randomString.getBytes();
            selected_file.setKey(k);
            Cipher c = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec sks = new SecretKeySpec(selected_file.getKey(), "AES");
            c.init(Cipher.DECRYPT_MODE, sks);
            decryptedValue = new String(c.doFinal(Base64.getDecoder().decode(contentsInEachFile[i])));


        } catch (Exception e) {
        }
        return decryptedValue; // return decrypted value

    }

}
