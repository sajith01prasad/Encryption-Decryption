
import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author sajithprasad
 */
public class selectedFolder {

    private String folder_name;
    private String folder_path;
    private String file_name;
    private byte[] encodedContent;
    private byte[] key;
    private File file;
    private String filePath;
    private String encodedContentString;

    public void setFolder_Name(String folder_name) {
        this.folder_name = folder_name;
    }

    public String getFolder_Name() {
        return this.folder_name;
    }

    public void setFolder_Path(String folder_path) {
        this.folder_path = folder_path;
    }

    public String getFolder_Path() {
        return this.folder_path;
    }

    public void setFile_Name(String file_Name) {
        this.file_name = file_Name;
    }

    /**
     *
     * @return
     */
    public String getFile_Name() {
        return this.file_name;
    }

    /**
     *
     * @param encodedContent
     */
    public void setEncodedContent(byte[] encodedContent) {
        this.encodedContent = encodedContent;
    }

    /**
     *
     * @return
     */
    public byte[] getEncodedContent() {
        return this.encodedContent;
    }

    /**
     *
     * @param key
     */
    public void setKey(byte[] key) {
        this.key = key;
    }

    /**
     *
     * @return
     */
    public byte[] getKey() {
        return this.key;
    }

    /**
     *
     * @param file
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     *
     * @return
     */
    public File getFile() {
        return this.file;
    }

    /**
     *
     * @param filePath
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     *
     * @return
     */
    public String getFilePath() {
        return this.filePath;
    }

    public void setEncodedContentString(String encodedContentString) {
        this.encodedContentString = encodedContentString;
    }

    public String getEncodedContentString() {
        return this.encodedContentString;
    }
}
