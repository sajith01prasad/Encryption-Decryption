
import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author toshi
 */
public class SelectedFile {

    private String file_name;
    private byte[] encodedContent;
    private byte[] key;
    private File file;
    private String filePath;
    private String encodedContentString;

    /**
     *
     * @param file_Name
     */
    public void setFile_Name(String file_Name) {
        this.file_name = file_Name;
    }

    /**
     *
     * @return
     */
    public String getFile_Name() {
        return this.file_name;
    }

    /**
     *
     * @param encodedContent
     */
    public void setEncodedContent(byte[] encodedContent) {
        this.encodedContent = encodedContent;
    }

    /**
     *
     * @return
     */
    public byte[] getEncodedContent() {
        return this.encodedContent;
    }

    /**
     *
     * @param key
     */
    public void setKey(byte[] key) {
        this.key = key;
    }

    /**
     *
     * @return
     */
    public byte[] getKey() {
        return this.key;
    }

    /**
     *
     * @param file
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     *
     * @return
     */
    public File getFile() {
        return this.file;
    }

    /**
     *
     * @param filePath
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     *
     * @return
     */
    public String getFilePath() {
        return this.filePath;
    }

    public void setEncodedContentString(String encodedContentString) {
        this.encodedContentString = encodedContentString;
    }

    public String getEncodedContentString() {
        return this.encodedContentString;
    }
}
